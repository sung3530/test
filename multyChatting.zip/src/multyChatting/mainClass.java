package multyChatting;

public class mainClass {

	public static void main(String[] args){
		logInGui lig=new logInGui();
		//ChattingGui cg=new ChattingGui("leesungho","127.0.0.1",9999);
	}
}
